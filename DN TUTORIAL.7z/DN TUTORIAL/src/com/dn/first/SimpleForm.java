

System.out.println("Esta es su Encuesta covid")

scanner = new Scanner(in);

System.out.println("Ha tenido tos en la ultima semana? (Si / No)")
String tos = scanner.nextline();
System.out.println("Ha tenido fiebre en las ultimas dos semanas? (Si/No)")
String fiebre = scanner.nextline();
System.out.println("Ha sentido debilidad fisica en las ultimas dos semanas? (Si/No)")
String debilidad = scanner.nextline();
System.out.println("Ha estado fuera del pais en el ultimo mes? (Si/No)")
String pais = scanner.nextline();
System.out.println("Ha estado en contacto con alguna persona con prueba positiva de Covid-19 (Si/No)?")
String contactoP = scanner.nextline();
System.out.println("Ha estado en contacto con alguna persona con sintomas de Covid-19? (Si/No)")
String contactoS = scanner.nextline();
System.out.println("Ha visitado alguna comunidad con altos indices de contagio de Covid-19? (Si/No")
String comunidad = scanner.nextline();


