package com.dn.first;

public class DatosCovid {

	//Sintomas Comunes
	String tos;
	String fiebre;
	String debilidad;
	String pais;
	String contactoP;
	String contactoS;
	String comunidad;
	
	public String gettos() {
		return tos;
	}
	public String getfiebre() {
		return fiebre;
	}
	public String getdebilidad() {
		return debilidad;
	}
	public String getpais() {
		return pais;
	}
	public String getcontactoP() {
		return contactoP;
	}
	public String getcontactoS() {
		return contactoS;
	}
	public String comunidad() {
		return comunidad;
	}
	
	public void settos(String tos) {
		return Tos = tos;
	}
	public void setfiebre(String fiebre) {
		return Fiebre = fiebre;
	}
	public void setdebilidad(String debilidad) {
		return Debilidad = debilidad;
	}
	public void setpais(String pais) {
		return Pais = pais;
	}
	public void setcontactoP(String contactoP) {
		return ContactoP = contactoP;
	}
	public void setcontactoS(String contactoS) {
		return ContactoS = contactoS;
	}
	public void setcomunidad(String comunidad) {
		return Comunidad = comunidad;
	}
	
	public DatosCovid (String tos, String fiebre, String debilidad, String pais, String contactoP, String contactoS, String comunidad) {
		Tos = tos;
		Fiebre = fiebre;
		Debilidad = debilidad;
		Pais = pais;
		ContactoP = contactoP;
		ContactoS = contactoS;
		Comunidad = comunidad;
	}
	
	@Override
	public void MostrarInformacion( ) {
		System.out.println("\n");
		System.out.println("- Informacion Covid-19 -");
		System.out.println("Sintoma de Tos : " +Tos);
		System.out.println("Sintoma de Fiebre : " +Fiebre);
		System.out.println("Sintoma de Debilidad : " +Debilidad);
		System.out.println("Expuesto al Extranjero : " +Pais);
		System.out.println("Expuesto a Caso Confirmado : " +ContactoP);
		System.out.println("Expuesto a Caso Sospechado : " +ContactoS);
		System.out.println("Expuesto a Comunidad Vulnerable : " +Comunidad);
		
		if(Tos == No && Fiebre == No && Debilidad == No && Pais == No && ContactoP == No && ContactoS == No && Comunidad == No) {
			System.out.println("El paciente no es de alto reisgo. Prosiga con Precaucion");
		}
		
		else{
			System.out.println("El paciente puede tener Covid-19. Recomendacion de Prueba y Cuarentena");
		}
	}
}
