
package HISTORIACLINICA;

public abstract class  HistorialClinicoP {


    public abstract void MostrarInformacion();
}
